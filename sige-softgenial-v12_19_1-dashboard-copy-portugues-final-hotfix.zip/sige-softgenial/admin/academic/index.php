<?php // Silêncio é ouro.
